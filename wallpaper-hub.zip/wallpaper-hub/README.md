# Backdrop — a wallpaper site backed by Supabase

A plain HTML/CSS/JS site — no build step, no framework. Anyone can browse and
preview wallpapers; logging in is required to download the full-resolution
file. You upload new wallpapers from `admin.html`, which only your admin
account can access.

## What's included

```
index.html          Public gallery + login/signup modal
admin.html           Admin upload panel
css/style.css        Shared styling
js/supabase-client.js  Where you paste your Supabase URL + anon key
js/auth.js            Shared auth helpers
js/app.js             Gallery + download logic
js/admin.js           Upload / delete logic
supabase-setup.sql    Full database + storage schema and security rules
```

## 1. Create a Supabase project

Go to [supabase.com](https://supabase.com), create a new project, and wait
for it to finish provisioning.

## 2. Run the database setup

Open **SQL Editor** in your Supabase dashboard, paste in the contents of
`supabase-setup.sql`, and run it. This creates:

- a `profiles` table (tracks who's an admin)
- a `wallpapers` table (title, category, storage paths, download count)
- a public **thumbnails** storage bucket (so previews load without login)
- a private **wallpapers** storage bucket (full-res files, login required)
- row-level security rules so only admins can upload/delete, and only
  logged-in users can download full-res files

## 3. Connect the site to your project

In Supabase, go to **Project Settings → API** and copy your **Project URL**
and **anon public key**. Paste them into `js/supabase-client.js`:

```js
const SUPABASE_URL = "https://xxxxx.supabase.co";
const SUPABASE_ANON_KEY = "eyJhbGciOiJIUzI1NiIs...";
```

## 4. Make yourself an admin

1. Open `index.html` (locally or once deployed) and sign up with the email
   you want to use as the site owner.
2. Back in the Supabase SQL Editor, run:
   ```sql
   update public.profiles set is_admin = true where email = 'you@example.com';
   ```
3. Open `admin.html` and log in with that account — you'll see the upload
   panel.

By default, Supabase requires email confirmation before a new account can
log in. You can turn this off for testing under **Authentication → Providers
→ Email → Confirm email**, or just confirm the email in your inbox.

## 5. Run it locally

Any static file server works, for example:

```bash
npx serve .
```

Then open the printed local URL.

## 6. Deploy

This is a static site, so it deploys anywhere that serves static files:
Vercel, Netlify, Cloudflare Pages, GitHub Pages, or your own server. Just
upload the whole folder — there's nothing to build.

## Notes on how access control works

- Wallpaper **metadata** (title, category, thumbnail) is public, so anyone
  can browse the gallery without an account.
- Thumbnails live in a public bucket, so previews always load.
- Full-resolution files live in a **private** bucket. The download button
  calls `createSignedUrl`, which only succeeds for a logged-in
  (`authenticated`) user — this is enforced by a database policy, not just
  hidden in the UI, so it can't be bypassed by calling the API directly.
- Only accounts with `is_admin = true` in the `profiles` table can upload or
  delete wallpapers — also enforced by database policy. You can promote more
  admins later by running the same `update` query with a different email.

## Customizing

- Change the site name in the `<div class="wordmark">` in `index.html` and
  `admin.html`.
- Colors, type, and spacing all live in `css/style.css` under `:root`.
- Thumbnail size/quality is set in `makeThumbnail()` in `js/admin.js`
  (defaults to 640px wide, JPEG quality 0.82).

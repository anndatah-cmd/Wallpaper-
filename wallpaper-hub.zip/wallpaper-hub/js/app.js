let currentUser = null;
let wallpapers = [];
let activeCategory = "all";
let authMode = "login";

const galleryEl = document.getElementById("gallery");
const filterBarEl = document.getElementById("filterBar");
const headerActionsEl = document.getElementById("headerActions");

const authBackdrop = document.getElementById("authBackdrop");
const authForm = document.getElementById("authForm");
const authMessage = document.getElementById("authMessage");
const authSubmit = document.getElementById("authSubmit");

// ---------- Auth UI ----------

function renderHeader() {
  if (currentUser) {
    headerActionsEl.innerHTML = `
      <span>${currentUser.email}</span>
      <button class="btn" id="logoutBtn">Log out</button>
    `;
    document.getElementById("logoutBtn").addEventListener("click", async () => {
      await signOut();
    });
  } else {
    headerActionsEl.innerHTML = `<button class="btn" id="loginBtn">Log in</button>`;
    document.getElementById("loginBtn").addEventListener("click", openAuthModal);
  }
}

function openAuthModal() {
  authMessage.textContent = "";
  authForm.reset();
  authBackdrop.classList.remove("hidden");
}

function closeAuthModal() {
  authBackdrop.classList.add("hidden");
}

document.getElementById("authClose").addEventListener("click", closeAuthModal);
authBackdrop.addEventListener("click", (e) => {
  if (e.target === authBackdrop) closeAuthModal();
});

document.querySelectorAll(".modal-tab").forEach((tab) => {
  tab.addEventListener("click", () => {
    authMode = tab.dataset.tab;
    document.querySelectorAll(".modal-tab").forEach((t) => t.classList.remove("active"));
    tab.classList.add("active");
    authSubmit.textContent = authMode === "login" ? "Log in" : "Create account";
    authMessage.textContent = "";
  });
});

authForm.addEventListener("submit", async (e) => {
  e.preventDefault();
  const email = document.getElementById("authEmail").value.trim();
  const password = document.getElementById("authPassword").value;
  authSubmit.disabled = true;
  authMessage.className = "form-message";
  authMessage.textContent = "";

  const { data, error } =
    authMode === "login" ? await signIn(email, password) : await signUp(email, password);

  authSubmit.disabled = false;

  if (error) {
    authMessage.className = "form-message error";
    authMessage.textContent = error.message;
    return;
  }

  if (authMode === "signup" && !data.session) {
    authMessage.className = "form-message success";
    authMessage.textContent = "Check your inbox to confirm your email, then log in.";
    return;
  }

  closeAuthModal();
});

// ---------- Gallery ----------

function thumbnailUrl(path) {
  return sb.storage.from("thumbnails").getPublicUrl(path).data.publicUrl;
}

function renderFilterBar() {
  const categories = ["all", ...new Set(wallpapers.map((w) => w.category || "uncategorized"))];
  filterBarEl.innerHTML = categories
    .map(
      (cat) =>
        `<button class="filter-chip ${cat === activeCategory ? "active" : ""}" data-category="${cat}">${
          cat === "all" ? "All" : cat
        }</button>`
    )
    .join("");

  filterBarEl.querySelectorAll(".filter-chip").forEach((chip) => {
    chip.addEventListener("click", () => {
      activeCategory = chip.dataset.category;
      renderFilterBar();
      renderGallery();
    });
  });
}

function renderGallery() {
  const visible =
    activeCategory === "all" ? wallpapers : wallpapers.filter((w) => (w.category || "uncategorized") === activeCategory);

  if (visible.length === 0) {
    galleryEl.innerHTML = `<p class="empty-state">No wallpapers here yet.</p>`;
    return;
  }

  galleryEl.innerHTML = visible
    .map(
      (w) => `
      <div class="card">
        <div class="thumb-wrap">
          <img src="${thumbnailUrl(w.thumbnail_path)}" alt="${w.title}" loading="lazy" />
        </div>
        <div class="card-body">
          <div class="card-title">${w.title}</div>
          <div class="card-meta">
            <span>${w.category || "uncategorized"}</span>
            <span>${w.width && w.height ? `${w.width}×${w.height}` : ""}</span>
          </div>
          <div class="card-footer">
            <button class="btn btn-accent" data-id="${w.id}">Download</button>
          </div>
        </div>
      </div>
    `
    )
    .join("");

  galleryEl.querySelectorAll("[data-id]").forEach((btn) => {
    btn.addEventListener("click", () => handleDownload(btn.dataset.id, btn));
  });
}

async function loadWallpapers() {
  const { data, error } = await sb
    .from("wallpapers")
    .select("*")
    .order("created_at", { ascending: false });

  if (error) {
    galleryEl.innerHTML = `<p class="empty-state">Couldn't load wallpapers: ${error.message}</p>`;
    return;
  }

  wallpapers = data;
  renderFilterBar();
  renderGallery();
}

async function handleDownload(id, btn) {
  if (!currentUser) {
    openAuthModal();
    return;
  }

  const wallpaper = wallpapers.find((w) => w.id === id);
  if (!wallpaper) return;

  const originalLabel = btn.textContent;
  btn.disabled = true;
  btn.textContent = "Preparing…";

  const { data, error } = await sb.storage
    .from("wallpapers")
    .createSignedUrl(wallpaper.storage_path, 60);

  if (error) {
    btn.textContent = "Failed — try again";
    btn.disabled = false;
    return;
  }

  const link = document.createElement("a");
  link.href = data.signedUrl;
  link.download = wallpaper.title;
  document.body.appendChild(link);
  link.click();
  link.remove();

  sb.rpc("increment_downloads", { wallpaper_id: id });

  btn.textContent = originalLabel;
  btn.disabled = false;
}

// ---------- Boot ----------

sb.auth.onAuthStateChange((_event, session) => {
  currentUser = session ? session.user : null;
  renderHeader();
});

(async function init() {
  const session = await getSession();
  currentUser = session ? session.user : null;
  renderHeader();
  await loadWallpapers();
})();
